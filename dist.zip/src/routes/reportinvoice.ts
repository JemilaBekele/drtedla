import express from 'express';
import { updateInvoiceWithHistory} from '../controllers/invoice/confirm';
import {getInvoicesCardsExpenses, getUnconfirmedInvoices} from '../controllers/invoice/report'


const router = express.Router();


router.route('/:id').patch(updateInvoiceWithHistory); 


router.route('/card').get(getInvoicesCardsExpenses); 

router.route('/invoice').patch(getUnconfirmedInvoices); // Delete a bicycle by ID

export default router;
