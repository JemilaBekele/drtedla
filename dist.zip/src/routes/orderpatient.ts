import express from 'express';
import {
  
  getDoctors,
  getpatients,
 
  fetchPatient,
} from '../controllers/order/order';


const router = express.Router();

  
router.route('/doctor').get(getDoctors);   

router.route('/').get(getpatients);   

// Patient-related routes
router.route('/').post(fetchPatient);


export default router;
