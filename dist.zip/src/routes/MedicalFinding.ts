import express from 'express';
import { createMedicalFinding, getMedicalFindings,getMedicalFinding,updateMedicalFinding,deleteMedicalFinding } from '../controllers/MedicalFinding/MedicalFinding';

const router = express.Router();

// Define routes for Bicycle
router.route('/:id').post(createMedicalFinding).get(getMedicalFindings);  

router.route('/detail/:patientId/record/:recordId').get(getMedicalFinding);                   // Get a single bicycle by ID                 // Get all bicycles
router.route('/:id').delete(deleteMedicalFinding);
router.route('/:id').patch(updateMedicalFinding);           // Delete a bicycle by ID

export default router;
