import express from 'express';
import {  createService, getAllServices, updateService, deleteService } from '../controllers/invoice/Service';

const router = express.Router();

// Define routes for Bicycle
router.route('/').post(createService);               // Create a new bicycle
router.route('/').get(getAllServices);                  // Get all bicycles
router.route('/delete').delete(deleteService);
router.route('/update').patch(updateService);           // Delete a bicycle by ID

export default router;
