import { Request, Response } from 'express';
import { StatusCodes } from 'http-status-codes';
import asyncWrapper from '../../middleware/async';
import Invoice from '../../models/Invoice';
import History from '../../models/history';
import Card from '../../models/card';
import Expense from '../../models/expense';
import BadRequestError from '../../errors/bad-request';

interface Query {
  'Invoice.createdBy.id'?: string; // Replacing username with createdBy.id
  'Invoice.receipt'?: boolean;
  createdAt?: {
    $gte?: Date;
    $lte?: Date;
  };
}

// POST: Retrieve invoices, cards, and expenses
const getInvoicesCardsExpenses = asyncWrapper(async (req: Request, res: Response): Promise<void> => {
  const { createdById, startDate, endDate, receipt } = req.body;

  if (!createdById && (!startDate || !endDate)) {
    throw new BadRequestError('Provide at least one filter: createdById or both start and end dates.');
  }

  try {
    const query: Query = {};
    let startDateObj: Date | null = null;
    let endDateObj: Date | null = null;

    // Add createdBy.id filter if provided
    if (createdById) {
      query['Invoice.createdBy.id'] = createdById;
    }

    // Add date range filter if both startDate and endDate are provided
    if (startDate && endDate) {
      startDateObj = new Date(startDate);
      endDateObj = new Date(endDate);

      if (isNaN(startDateObj.getTime()) || isNaN(endDateObj.getTime())) {
        throw new BadRequestError('Invalid date format.');
      }

      if (endDateObj < startDateObj) {
        throw new BadRequestError('End date must be greater than or equal to start date.');
      }

      // Include the end of the day for the endDate
      endDateObj.setHours(23, 59, 59, 999);

      query.createdAt = { $gte: startDateObj, $lte: endDateObj };
    }

    // Add receipt filter if provided
    if (receipt !== undefined) {
      query['Invoice.receipt'] = receipt;
    }

    // Retrieve history based on query
    const history = await History.find(query);

    let cards = [];
    let expenses = [];
    if (!createdById) {
      // Retrieve cards and expenses if createdById is not provided
      cards = await Card.find({
        createdAt: { $gte: startDateObj, $lte: endDateObj },
      });

      expenses = await Expense.find({
        createdAt: { $gte: startDateObj, $lte: endDateObj },
      });
    }

    res.status(StatusCodes.OK).json({
      message: 'Invoices, cards, and expenses retrieved successfully.',
      success: true,
      data: { history, cards, expenses },
    });
  } catch (error) {
    console.error('Error fetching invoices, cards, and expenses:', error);
    res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
      message: 'Failed to retrieve invoices, cards, and expenses.',
      success: false,
    });
  }
});

// GET: Retrieve invoices with unconfirmed payments
const getUnconfirmedInvoices = asyncWrapper(async (_req: Request, res: Response): Promise<void> => {
  try {
    const invoices = await Invoice.find({
      'currentpayment.confirm': false,
    });

    res.status(StatusCodes.OK).json({
      message: 'Invoices with unconfirmed payments retrieved successfully.',
      success: true,
      data: invoices,
    });
  } catch (error) {
    console.error('Error fetching unconfirmed invoices:', error);
    res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
      message: 'Failed to retrieve unconfirmed invoices.',
      success: false,
    });
  }
});

export { getInvoicesCardsExpenses, getUnconfirmedInvoices };
