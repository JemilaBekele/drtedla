import { Request, Response } from 'express';
import { StatusCodes } from 'http-status-codes';
import asyncWrapper from '../../middleware/async';
import Service from '../../models/Services';
import BadRequestError from '../../errors/bad-request';
import NotFoundError from '../../errors/not-found';






const createService = asyncWrapper(async (req: Request, res: Response): Promise<void> => {
  const { service, price } = req.body;

  // Validate request
  if (!service || !price) {
    throw new BadRequestError('Service and price are required');
  }

  // Check if the service already exists
  const existingService = await Service.findOne({ service });
  if (existingService) {
    throw new BadRequestError('Service already exists');
  }

  // Create new service
  const newService = await Service.create({
    service,
    price,
  });

  // Send response
  res.status(StatusCodes.CREATED).json({
    message: 'Service registered successfully',
    service: newService,
  });
});





const getAllServices = asyncWrapper(async (req: Request, res: Response): Promise<void> => {
  try {
    // Fetch all services from the database
    const services = await Service.find();

    // Return the services
    res.status(StatusCodes.OK).json(services);
  } catch (error) {
    console.error('Error fetching services:', error);

    // Return a generic error response
    res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
      message: 'Failed to fetch services',
    });
  }
});




const updateService = asyncWrapper(async (req: Request, res: Response): Promise<void> => {
  const { id, service, price } = req.body;

  // Validate inputs
  if (!id || (!service && !price)) {
    throw new BadRequestError('Service ID and at least one field (service or price) are required');
  }

  // Find and update the service by its ID
  const updatedService = await Service.findByIdAndUpdate(
    id,
    { service, price },
    { new: true } // Return the updated document
  );

  console.log("update")
  if (!updatedService) {
    throw new NotFoundError('Service not found');
  }

  res.status(StatusCodes.OK).json({
    message: 'Service updated successfully',
    service: updatedService,
  });
});




const deleteService = asyncWrapper(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.body;

  // Validate input
  if (!id) {
    throw new BadRequestError('Service ID is required');
  }

  // Find and delete the service by its ID
  const deletedService = await Service.findByIdAndDelete(id);

  if (!deletedService) {
    throw new NotFoundError('Service not found');
  }

  res.status(StatusCodes.OK).json({
    message: 'Service deleted successfully',
  });
});



export { createService, getAllServices, updateService, deleteService  };