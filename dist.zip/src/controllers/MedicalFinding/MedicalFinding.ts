import { Request, Response } from 'express';
import { StatusCodes } from 'http-status-codes';
import asyncWrapper from '../../middleware/async';
import MedicalFinding from '../../models/MedicalFinding';
import Patient from '../../models/Patient';
import BadRequestError from '../../errors/bad-request';
import NotFoundError from '../../errors/not-found';

interface AuthenticatedRequest extends Request {
  user?: {
    userId: string;
    username: string;
  };
}

// Create a new medical finding
const createMedicalFinding = asyncWrapper(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    
  const { id } = req.params; // Patient ID from URL params

  if (!id) {
    throw new BadRequestError('Patient ID is required');
  }

  const {
    ChiefCompliance,
    Historypresent,
    Vitalsign,
    Pastmedicalhistory,
    Pastdentalhistory,
    IntraoralExamination,
    ExtraoralExamination,
    Investigation,
    Assessment,
    TreatmentPlan,
    TreatmentDone,
  } = req.body;

  // Validate patient existence
  const patient = await Patient.findById(id).exec();
  if (!patient) {
    throw new NotFoundError('Patient not found');
  }

  const createdBy = {
    id: req.user?.userId || '',
    username: req.user?.username || '',
  };

  // Create a new MedicalFinding
  const newMedicalFinding = new MedicalFinding({
    ChiefCompliance,
    Historypresent,
    Vitalsign,
    Pastmedicalhistory,
    Pastdentalhistory,
    IntraoralExamination,
    ExtraoralExamination,
    Investigation,
    Assessment,
    TreatmentPlan,
    TreatmentDone,
    patientId: { id: patient._id },
    createdBy,
  });

  const savedFinding = await newMedicalFinding.save();

  // Link the medical finding to the patient
  patient.MedicalFinding = patient.MedicalFinding || [];
  patient.MedicalFinding.push(savedFinding._id);
  await patient.save();

  res.status(StatusCodes.CREATED).json({
    message: 'Medical finding created successfully',
    success: true,
    data: savedFinding,
  });
});

// Get medical findings for a patient
const getMedicalFindings = asyncWrapper(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.params; // Patient ID from URL params

  if (!id) {
    throw new BadRequestError('Patient ID is required');
  }

  // Find the patient by ID and populate MedicalFinding
  const patient = await Patient.findById(id).populate('MedicalFinding').exec();
  if (!patient) {
    throw new NotFoundError('Patient not found');
  }

  if (!patient.MedicalFinding || patient.MedicalFinding.length === 0) {
    res.status(StatusCodes.OK).json({
      message: 'No medical findings available for this patient',
      data: [],
    });
    return;
  }

  // Sort medical findings by `createdAt` in descending order
  const sortedFindings = patient.MedicalFinding.sort((a: any, b: any) => {
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  res.status(StatusCodes.OK).json({
    message: 'Medical findings retrieved successfully',
    success: true,
    data: sortedFindings,
  });
});



// Get a specific medical finding
const getMedicalFinding = asyncWrapper(async (req: Request, res: Response): Promise<void> => {
  const { patientId, recordId } = req.params;

  if (!patientId || !recordId) {
    throw new BadRequestError('Patient ID and Finding ID are required');
  }

  const patient = await Patient.findById(patientId).exec();
  if (!patient) {
    throw new NotFoundError('Patient not found');
  }

  const finding = await MedicalFinding.findById(recordId).exec();
  if (!finding) {
    throw new NotFoundError('Medical finding not found');
  }

  res.status(StatusCodes.OK).json({
    message: 'Medical finding retrieved successfully',
    success: true,
    data: finding,
  });
});

// Update a medical finding
const updateMedicalFinding = asyncWrapper(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const { recordId, ...data } = req.body;

  if (!recordId) {
    throw new BadRequestError('Finding ID is required');
  }

  const updatedFinding = await MedicalFinding.findByIdAndUpdate(recordId, data, { new: true }).exec();
  if (!updatedFinding) {
    throw new NotFoundError('Medical finding not found');
  }

  res.status(StatusCodes.OK).json({
    message: 'Medical finding updated successfully',
    success: true,
    data: updatedFinding,
  });
});

// Delete a medical finding
const deleteMedicalFinding = asyncWrapper(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    const { recordId } = req.body;
  
    if (!recordId) {
      throw new BadRequestError('Finding ID is required');
    }
  
    // Find and delete the medical finding by ID
    const deletedFinding = await MedicalFinding.findByIdAndDelete(recordId).exec();
    if (!deletedFinding) {
      throw new NotFoundError('Medical finding not found');
    }
  
    // Remove the reference from the associated patient
    await Patient.updateOne(
      { MedicalFinding: recordId }, // Locate the patient containing the reference
      { $pull: { MedicalFinding: recordId } } // Remove the reference from the array
    ).exec();
  
    res.status(StatusCodes.OK).json({
      message: 'Medical finding deleted successfully',
      success: true,
    });
  });
  



export { createMedicalFinding, getMedicalFindings,getMedicalFinding,updateMedicalFinding,deleteMedicalFinding };
