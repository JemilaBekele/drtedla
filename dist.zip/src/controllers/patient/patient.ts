import { Request, Response } from 'express';
import { StatusCodes } from 'http-status-codes';
import asyncWrapper from '../../middleware/async';
import Patient from '../../models/Patient';
import BadRequestError from '../../errors/bad-request';
import NotFoundError from '../../errors/not-found';

interface AuthenticatedRequest extends Request {
  user?: {
    userId: string;
    username: string;
    role: string;
  };
}

// Create a new bicycle
const createPatient = asyncWrapper(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const { cardno, firstname, age,sex , phoneNumber, Town, KK, HNo,  description } = req.body;
  
  const createdBy = {
    id: req.user?.userId || '', 
    username: req.user?.username || '', 
  };

  const existingPatient = await Patient.findOne({ cardno });
  if (existingPatient) {
    throw new BadRequestError('Patient ID already exists. Please use a unique bicycle ID.');
  }

  const patient = await Patient.create({ cardno, firstname, age,sex , phoneNumber, Town, KK, HNo,  description , createdBy });
  res.status(StatusCodes.CREATED).json({ patient });
});

// Get a single bicycle by ID
const getpatient = asyncWrapper(async (req: Request, res: Response): Promise<void> => {
  const { id :PatientId} = req.params;

  if (!PatientId) {
    throw new BadRequestError('Patient ID is required');
  }

  // Pass the ObjectId directly to findById
  const patient = await Patient.findById({_id: PatientId});
  if (!patient) {
    throw new NotFoundError(`No Patient found with ID: ${PatientId}`);
  }

  res.status(StatusCodes.OK).json({ patient });
});

// Get all bicycles
const getAllpatient = asyncWrapper(async (_req: Request, res: Response): Promise<void> => {
  const patients = await Patient.find({});
  console.log(patients)
  res.status(StatusCodes.OK).json({ patients});
});

// Delete a bicycle by ID
const deletepatient = asyncWrapper(async (req: Request, res: Response): Promise<void> => {
  const { id: PatientId } = req.params;

  if (!PatientId) {
    throw new BadRequestError('patient ID is required');
  }

  // Pass the ObjectId directly to findByIdAndDelete
  const patient = await Patient.findByIdAndDelete({_id: PatientId});
  if (!patient) {
    throw new NotFoundError(`No Patient found with ID: ${PatientId}`);
  }

  res.status(StatusCodes.OK).json({ message: 'Patient deleted successfully' });
});


const updatepatient = asyncWrapper(async (req: Request, res: Response): Promise<void> => {
  const { id: PatientId } = req.params;

  if (!PatientId) {
    throw new BadRequestError('Patient ID is required');
  }

  const updatedpatient = await Patient.findByIdAndUpdate(
    PatientId,
    req.body, // Update with the fields provided in the request body
    {
      new: true, // Return the updated document
      runValidators: true, // Ensure the update adheres to schema validation
    }
  );

  if (!updatedpatient) {
    throw new NotFoundError(`No Patient found with ID: ${PatientId}`);
  }

  res.status(StatusCodes.OK).json({ message: 'Patient updated successfully', Patient: updatedpatient });
});



export { createPatient, getpatient ,updatepatient, getAllpatient, deletepatient };
